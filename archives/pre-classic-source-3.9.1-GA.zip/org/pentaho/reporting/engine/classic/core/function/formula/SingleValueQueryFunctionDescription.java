package org.pentaho.reporting.engine.classic.core.function.formula;

import org.pentaho.reporting.libraries.formula.function.AbstractFunctionDescription;
import org.pentaho.reporting.libraries.formula.function.FunctionCategory;
import org.pentaho.reporting.libraries.formula.function.userdefined.UserDefinedFunctionCategory;
import org.pentaho.reporting.libraries.formula.typing.Type;
import org.pentaho.reporting.libraries.formula.typing.coretypes.AnyType;
import org.pentaho.reporting.libraries.formula.typing.coretypes.NumberType;
import org.pentaho.reporting.libraries.formula.typing.coretypes.TextType;

/**
 * Todo: Document me!
 * <p/>
 * Date: 16.07.2010
 * Time: 19:39:03
 *
 * @author Thomas Morgner.
 */
public class SingleValueQueryFunctionDescription extends AbstractFunctionDescription
{
  public SingleValueQueryFunctionDescription()
  {
    super("SINGLEVALUEQUERY", "org.pentaho.reporting.engine.classic.core.function.formula.SingleValueQuery-Function");
  }

  public Type getValueType()
  {
    return AnyType.TYPE;
  }

  public FunctionCategory getCategory()
  {
    return UserDefinedFunctionCategory.CATEGORY;
  }

  public int getParameterCount()
  {
    return 3;
  }

  /**
   * Returns the parameter type at the given position using the function
   * metadata. The first parameter is at the position 0;
   *
   * @param position The parameter index.
   * @return The parameter type.
   */
  public Type getParameterType(final int position)
  {
    switch (position)
    {
      case 0:
        return TextType.TYPE;
      case 1:
        return TextType.TYPE;
      case 2:
        return NumberType.GENERIC_NUMBER;
    }
    return AnyType.TYPE;
  }

  /**
   * Defines, whether the parameter at the given position is mandatory. A
   * mandatory parameter must be filled in, while optional parameters need
   * not to be filled in.
   *
   * @return
   */
  public boolean isParameterMandatory(final int position)
  {
    return position == 0;
  }
}