/*
 * This program is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License, version 2.1 as published by the Free Software
 * Foundation.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * program; if not, you can obtain a copy at http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
 * or from the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * Copyright (c) 2001 - 2009 Object Refinery Ltd, Pentaho Corporation and Contributors..  All rights reserved.
 */

package org.pentaho.reporting.engine.classic.core.style;

/**
 * The interface that must be supported by objects that wish to receive notification of style change events.
 *
 * @author Thomas Morgner
 */
public interface StyleChangeListener
{
  /**
   * Receives notification that a style has changed.
   *
   * @param source the source of the change.
   * @param key    the style key.
   * @param value  the value.
   */
  public void styleChanged(ElementStyleSheet source, StyleKey key, Object value);

  /**
   * Receives notification that a style has been removed.
   *
   * @param source the source of the change.
   * @param key    the style key.
   */
  public void styleRemoved(ElementStyleSheet source, StyleKey key);
}
