/*
 * This program is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License, version 2.1 as published by the Free Software
 * Foundation.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * program; if not, you can obtain a copy at http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
 * or from the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * Copyright (c) 2009 Pentaho Corporation.  All rights reserved.
 */

package org.pentaho.reporting.designer.core.util.table;

import java.beans.PropertyEditor;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.table.AbstractTableModel;

import org.pentaho.reporting.designer.core.util.UtilMessages;
import org.pentaho.reporting.libraries.designtime.swing.bulk.BulkDataProvider;

/**
 * Todo: Document Me
 *
 * @author Thomas Morgner
 * @noinspection unchecked
 */
public class ArrayTableModel extends AbstractTableModel implements BulkDataProvider, ElementMetaDataTableModel
{
  private ArrayList data;
  private Class type;
  private String valueRole;
  private Class propertyEditorType;
  private String[] extraFields;
  private String columnTitle;

  public ArrayTableModel()
  {
    data = new ArrayList();
    type = Object.class;
    extraFields = new String[0];
    columnTitle = UtilMessages.getInstance().getString("ArrayTableModel.Value");
  }

  public String getColumnTitle()
  {
    return columnTitle;
  }

  public void setColumnTitle(final String columnTitle)
  {
    this.columnTitle = columnTitle;
  }

  public Object[] getData()
  {
    return data.toArray();
  }

  public void setData(final Object[] data, final Class componentType)
  {
    if (componentType == null)
    {
      throw new NullPointerException();
    }
    if (data == null)
    {
      throw new NullPointerException();
    }
    this.data.clear();
    this.data.addAll(Arrays.asList(data));
    this.type = componentType;

    fireTableDataChanged();
  }

  public int getRowCount()
  {
    return data.size();
  }

  public int getColumnCount()
  {
    return 1;
  }

  public Object getValueAt(final int rowIndex, final int columnIndex)
  {
    return data.get(rowIndex);
  }

  public void setValueAt(final Object aValue, final int rowIndex, final int columnIndex)
  {
    data.set(rowIndex, aValue);
    fireTableCellUpdated(rowIndex, columnIndex);
  }

  public boolean isCellEditable(final int rowIndex, final int columnIndex)
  {
    return true;
  }

  public Class getColumnClass(final int columnIndex)
  {
    return type;
  }

  public String getColumnName(final int column)
  {
    return columnTitle;
  }

  public void add(final Object o)
  {
    data.add(o);
    fireTableDataChanged();
  }

  public Object get(final int index)
  {
    return data.get(index);
  }

  public void remove(final int index)
  {
    data.remove(index);
    fireTableDataChanged();
  }

  public void clear()
  {
    data.clear();
    fireTableDataChanged();
  }

  public Object[] toArray()
  {
    return getData();
  }

  public int getSize()
  {
    return getRowCount();
  }

  public int getBulkDataSize()
  {
    return getRowCount();
  }

  public Object[] getBulkData()
  {
    return getData();
  }

  public void setBulkData(final Object[] data)
  {
    setData(data, type);
  }

  public Class getClassForCell(final int row, final int column)
  {
    return type;
  }

  public Class getType()
  {
    return type;
  }

  public void setType(final Class type)
  {
    this.type = type;
  }

  public Class getPropertyEditorType()
  {
    return propertyEditorType;
  }

  public void setPropertyEditorType(final Class propertyEditorType)
  {
    this.propertyEditorType = propertyEditorType;
  }

  public PropertyEditor getEditorForCell(final int row, final int column)
  {
    if (propertyEditorType == null)
    {
      return null;
    }
    try
    {
      return (PropertyEditor) propertyEditorType.newInstance();
    }
    catch (Exception e)
    {
      return null;
    }
  }

  public void setValueRole(final String valueRole)
  {
    this.valueRole = valueRole;
  }

  public String getValueRole(final int row, final int column)
  {
    return valueRole;
  }

  public void setExtraFields(final String[] extraFields)
  {
    this.extraFields = extraFields.clone();
  }

  public String[] getExtraFields(final int row, final int column)
  {
    return extraFields.clone();
  }

  public void setTableStyle(final TableStyle tableStyle)
  {

  }

  public TableStyle getTableStyle()
  {
    return TableStyle.ASCENDING;
  }
}
