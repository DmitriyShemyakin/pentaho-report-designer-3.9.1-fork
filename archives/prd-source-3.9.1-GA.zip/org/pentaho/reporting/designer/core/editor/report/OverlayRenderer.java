/*
 * This program is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License, version 2.1 as published by the Free Software
 * Foundation.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * program; if not, you can obtain a copy at http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
 * or from the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * Copyright (c) 2009 Pentaho Corporation.  All rights reserved.
 */

package org.pentaho.reporting.designer.core.editor.report;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.ImageObserver;

import org.pentaho.reporting.designer.core.editor.ReportRenderContext;

/**
 * Overlay renderers draw additional information on the canvas. This drawing happens after the complete
 * logical page has been rendered and always happens on the natural zoom level (where one point equals one
 * pixel). 
 *
 * @author Thomas Morgner.
 */
public interface OverlayRenderer
{
  public void validate(final ReportRenderContext context, final double zoomFactor);
  public void draw(final Graphics2D graphics, final Rectangle2D bounds, final ImageObserver obs);
}
