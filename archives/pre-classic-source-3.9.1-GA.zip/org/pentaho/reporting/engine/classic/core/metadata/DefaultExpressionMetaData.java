/*
 * This program is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License, version 2.1 as published by the Free Software
 * Foundation.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * program; if not, you can obtain a copy at http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
 * or from the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * Copyright (c) 2001 - 2009 Object Refinery Ltd, Pentaho Corporation and Contributors..  All rights reserved.
 */

package org.pentaho.reporting.engine.classic.core.metadata;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.util.HashMap;

import org.pentaho.reporting.engine.classic.core.function.Function;

public class DefaultExpressionMetaData extends AbstractMetaData implements ExpressionMetaData
{
  public static final int NO_LAYOUT_PROCESSOR = 0;
  public static final int ELEMENT_LAYOUT_PROCESSOR = 1;
  public static final int GLOBAL_LAYOUT_PROCESSOR = 2;

  private Class expressionType;
  private Class resultType;
  private HashMap properties;
  private BeanInfo beanInfo;
  private int layoutProcessorMode;

  private transient String[] propertyKeys;
  private transient ExpressionPropertyMetaData[] propertyMetaData;

  public DefaultExpressionMetaData(final String bundleLocation,
                                   final boolean expert,
                                   final boolean preferred,
                                   final boolean hidden,
                                   final boolean deprecated,
                                   final Class expressionType,
                                   final Class resultType,
                                   final HashMap attributes,
                                   final BeanInfo beanInfo,
                                   final int layoutProcessorMode,
                                   final boolean experimental,
                                   final int compatibilityLevel)
  {
    super(expressionType.getName(), bundleLocation, "",
        expert, preferred, hidden, deprecated, experimental, compatibilityLevel);
    if (resultType == null)
    {
      throw new NullPointerException();
    }
    if (attributes == null)
    {
      throw new NullPointerException();
    }
    if (beanInfo == null)
    {
      throw new NullPointerException();
    }

    this.expressionType = expressionType;
    this.layoutProcessorMode = layoutProcessorMode;
    this.resultType = resultType;
    this.properties = (HashMap) attributes.clone();
    this.beanInfo = beanInfo;
  }

  protected String computePrefix(final String keyPrefix, final String name)
  {
    return "";
  }

  public boolean isStatefull()
  {
    return Function.class.isAssignableFrom(getExpressionType());
  }

  public Class getResultType()
  {
    return resultType;
  }

  public Class getExpressionType()
  {
    return expressionType;
  }

  public ExpressionPropertyMetaData getPropertyDescription(final String name)
  {
    return (ExpressionPropertyMetaData) properties.get(name);
  }

  public String[] getPropertyNames()
  {
    if (propertyKeys == null)
    {
      propertyKeys = (String[]) properties.keySet().toArray(new String[properties.size()]);
    }
    return propertyKeys;
  }

  public ExpressionPropertyMetaData[] getPropertyDescriptions()
  {
    if (propertyMetaData == null)
    {
      propertyMetaData = (ExpressionPropertyMetaData[]) properties.values().toArray
          (new ExpressionPropertyMetaData[properties.size()]);
    }
    return propertyMetaData;
  }

  public BeanInfo getBeanDescriptor() throws IntrospectionException
  {
    return beanInfo;
  }

  /**
   * Checks whether the main purpose of the expression is to modify the layout of the report. This method returns true,
   * if the expression modifies one or more named elements.
   *
   * @return true, if this is a layout-processor that modifies named elements.
   */
  public boolean isElementLayoutProcessor()
  {
    return layoutProcessorMode == DefaultExpressionMetaData.ELEMENT_LAYOUT_PROCESSOR;
  }

  /**
   * Checks whether the main purpose of the expression is to modify the layout of the report. This method returns true,
   * if the expression modifies the global layout only.
   *
   * @return true, if this is a layout-processor that modifies the global layout.
   */
  public boolean isGlobalLayoutProcessor()
  {
    return layoutProcessorMode == DefaultExpressionMetaData.GLOBAL_LAYOUT_PROCESSOR;
  }

  public boolean equals(final Object o)
  {
    if (this == o)
    {
      return true;
    }
    if (o == null || getClass() != o.getClass())
    {
      return false;
    }

    final DefaultExpressionMetaData that = (DefaultExpressionMetaData) o;

    if (!expressionType.equals(that.expressionType))
    {
      return false;
    }

    return true;
  }

  public int hashCode()
  {
    return expressionType.hashCode();
  }
}