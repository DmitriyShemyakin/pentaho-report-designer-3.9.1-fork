/*
 * This program is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License, version 2.1 as published by the Free Software
 * Foundation.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * program; if not, you can obtain a copy at http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
 * or from the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * Copyright (c) 2009 Pentaho Corporation..  All rights reserved.
 */

package org.pentaho.reporting.engine.classic.core.metadata;

import java.util.Locale;

/**
 * Todo: Document Me
 *
 * @author Thomas Morgner
 */
public interface MetaData
{
  public String getName();

  public String getDisplayName(Locale locale);

  public String getMetaAttribute(String attributeName, Locale locale);

  public String getGrouping(Locale locale);

  public int getGroupingOrdinal(Locale locale);

  public int getItemOrdinal(Locale locale);

  public String getDeprecationMessage(Locale locale);

  public String getDescription(Locale locale);

  public boolean isDeprecated();

  public boolean isExpert();

  public boolean isPreferred();

  public boolean isHidden();

  public boolean isExperimental();

  public int getCompatibilityLevel();
}
