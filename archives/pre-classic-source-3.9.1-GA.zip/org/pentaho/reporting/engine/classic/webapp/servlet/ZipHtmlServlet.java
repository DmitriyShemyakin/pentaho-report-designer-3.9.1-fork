/*
 * This program is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License, version 2.1 as published by the Free Software
 * Foundation.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * program; if not, you can obtain a copy at http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
 * or from the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * Copyright (c) 2009 Pentaho Corporation.  All rights reserved.
 */

package org.pentaho.reporting.engine.classic.webapp.servlet;

import java.io.IOException;
import java.net.URL;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;

import org.pentaho.reporting.engine.classic.core.MasterReport;
import org.pentaho.reporting.engine.classic.core.ReportProcessingException;
import org.pentaho.reporting.engine.classic.core.modules.parser.base.ReportGenerator;
import org.pentaho.reporting.engine.classic.core.modules.output.table.html.HtmlReportUtil;
import org.pentaho.reporting.libraries.resourceloader.ResourceException;

/**
 * Generates a ZIP file that contains the report.
 *
 * @author Thomas Morgner
 */
public class ZipHtmlServlet extends HttpServlet
{
  public ZipHtmlServlet()
  {
  }

  protected void doGet(final HttpServletRequest request,
                       final HttpServletResponse response) throws ServletException, IOException
  {
    final String reportDefinition = request.getParameter("report-definition");
    final URL reportUrl = getServletContext().getResource(reportDefinition);
    if (reportUrl == null)
    {
      response.sendError(HttpServletResponse.SC_BAD_REQUEST);
      return;
    }

    try
    {
      final MasterReport report = ReportGenerator.getInstance().parseReport(reportUrl);
      response.setContentType("application/zip");

      final ServletOutputStream stream = response.getOutputStream();
      HtmlReportUtil.createZIPHTML(report, stream, "report.html");
      stream.flush();
    }
    catch (ResourceException e)
    {
      log("Failed to parse report", e);
      response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
    }
    catch (ReportProcessingException e)
    {
      log("Failed to process the report", e);
      response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
    }
  }

  protected void doPost(final HttpServletRequest httpServletRequest,
                        final HttpServletResponse httpServletResponse) throws ServletException, IOException
  {
    doGet(httpServletRequest, httpServletResponse);
  }
}
