/*
 * This program is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License, version 2.1 as published by the Free Software
 * Foundation.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * program; if not, you can obtain a copy at http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
 * or from the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * Copyright (c) 2001 - 2009 Object Refinery Ltd, Pentaho Corporation and Contributors..  All rights reserved.
 */

package org.pentaho.reporting.engine.classic.core.filter.templates;

import java.awt.geom.Line2D;

import org.pentaho.reporting.engine.classic.core.Element;
import org.pentaho.reporting.engine.classic.core.function.ExpressionRuntime;

/**
 * Defines a horizontal line template. The line always has the width of 100 points. This implementation is used to cover
 * the common use of the line shape element. Use the scaling feature of the shape element to adjust the size of the
 * line.
 *
 * @author Thomas Morgner
 */
public class HorizontalLineTemplate extends AbstractTemplate
{
  /**
   * Default Constructor.
   */
  public HorizontalLineTemplate()
  {
  }

  /**
   * Returns the template value, an horizontal line.
   *
   * @param runtime the expression runtime that is used to evaluate formulas and expressions when computing the value of
   *                this filter.
   * @param element
   * @return a horizontal line with a width of 100.
   */
  public Object getValue(final ExpressionRuntime runtime, final Element element)
  {
    return new Line2D.Float(0, 0, 100, 0);
  }
}
