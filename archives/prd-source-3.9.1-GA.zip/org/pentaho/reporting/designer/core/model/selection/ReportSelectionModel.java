/*
 * This program is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License, version 2.1 as published by the Free Software
 * Foundation.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * program; if not, you can obtain a copy at http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
 * or from the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * Copyright (c) 2008 - 2009 Pentaho Corporation, .  All rights reserved.
 */

package org.pentaho.reporting.designer.core.model.selection;

import org.pentaho.reporting.engine.classic.core.Element;

/**
 * Todo: Document Me
 *
 * @author Thomas Morgner
 */
public interface ReportSelectionModel
{
  public boolean add(Object o);

  public void remove(Object o);

  public boolean isSelected(Object o);

  public void clearSelection();

  public Element[] getSelectedVisualElements();

  public int getSelectionCount();

  public Object[] getSelectedElements();

  public Object getSelectedElement(int index);

  public void setSelectedElements(Object[] elements);

  public void addReportSelectionListener(ReportSelectionListener listener);

  public void removeReportSelectionListener(ReportSelectionListener listener);

  public Object getLeadSelection();
}
