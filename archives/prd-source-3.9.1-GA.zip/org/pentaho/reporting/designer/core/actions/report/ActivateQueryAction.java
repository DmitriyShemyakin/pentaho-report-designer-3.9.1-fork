/*
 * This program is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License, version 2.1 as published by the Free Software
 * Foundation.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * program; if not, you can obtain a copy at http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
 * or from the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * Copyright (c) 2009 Pentaho Corporation.  All rights reserved.
 */

package org.pentaho.reporting.designer.core.actions.report;

import java.awt.event.ActionEvent;
import javax.swing.Action;

import org.pentaho.reporting.designer.core.actions.AbstractElementSelectionAction;
import org.pentaho.reporting.designer.core.actions.ActionMessages;
import org.pentaho.reporting.designer.core.actions.ToggleStateAction;
import org.pentaho.reporting.designer.core.editor.structuretree.ReportQueryNode;
import org.pentaho.reporting.designer.core.model.selection.ReportSelectionModel;
import org.pentaho.reporting.libraries.base.util.ObjectUtilities;

/**
 * Todo: Document me!
 * <p/>
 * Date: 12.04.2009
 * Time: 18:06:41
 *
 * @author Thomas Morgner.
 */
public class ActivateQueryAction extends AbstractElementSelectionAction implements ToggleStateAction
{
  private boolean selected;

  public ActivateQueryAction()
  {
    putValue(Action.NAME, ActionMessages.getString("ActivateQueryAction.Text"));
    putValue(Action.SHORT_DESCRIPTION, ActionMessages.getString("ActivateQueryAction.Description"));
    putValue(Action.MNEMONIC_KEY, ActionMessages.getOptionalMnemonic("ActivateQueryAction.Mnemonic"));
    putValue(Action.ACCELERATOR_KEY, ActionMessages.getOptionalKeyStroke("ActivateQueryAction.Accelerator"));
  }

  public boolean isSelected()
  {
    return selected;
  }

  public void setSelected(final boolean selected)
  {
    final boolean oldSelected = this.selected;
    this.selected = selected;
    firePropertyChange(ToggleStateAction.SELECTED, oldSelected, selected);
  }

  protected void updateSelection()
  {
    final ReportSelectionModel reportSelectionModel = getSelectionModel();
    if (reportSelectionModel == null)
    {
      setEnabled(false);
      return;
    }


    final Object[] selectedElements = reportSelectionModel.getSelectedElements();
    for (int i = 0; i < selectedElements.length; i++)
    {
      final Object selectedElement = selectedElements[i];
      if (selectedElement instanceof ReportQueryNode)
      {
        final ReportQueryNode node = (ReportQueryNode) selectedElement;
        setSelected (ObjectUtilities.equal(node.getQueryName(), getActiveContext().getReportDefinition().getQuery()));
        setEnabled(true);
        return;
      }
    }

    setEnabled(false);
  }

  public void actionPerformed(final ActionEvent e)
  {
    final ReportSelectionModel reportSelectionModel = getSelectionModel();
    if (reportSelectionModel == null)
    {
      return;
    }

    final Object[] selectedElements = reportSelectionModel.getSelectedElements();
    for (int i = 0; i < selectedElements.length; i++)
    {
      final Object selectedElement = selectedElements[i];
      if (selectedElement instanceof ReportQueryNode)
      {
        final ReportQueryNode node = (ReportQueryNode) selectedElement;
        getActiveContext().getReportDefinition().setQuery(node.getQueryName());
        return;
      }
    }
  }
}
