package org.pentaho.reporting.designer.core.editor.drilldown.basic;

import org.pentaho.reporting.designer.core.ReportDesignerContext;
import org.pentaho.reporting.designer.core.editor.drilldown.model.DrillDownModel;
import org.pentaho.ui.xul.impl.XulEventHandler;

/**
 * Todo: Document me!
 * <p/>
 *
 * @author Thomas Morgner.
 */
public interface XulDrillDownController extends XulEventHandler
{
  public DrillDownModel getModel();
  public void init(final ReportDesignerContext reportDesignerContext,
                   final DrillDownModel model);
  public void deactivate();
}
